package a7;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class PixelInspectorWidget extends JPanel implements MouseListener {
	
	private PictureView pictureView; 
	private  JPanel labelPanel = new JPanel(); 
	private int xCoordinate, yCoordinate; 
	private double red, green, blue, brightness; 
	
	
	
	public PixelInspectorWidget(Picture picture) {
		setLayout(new BorderLayout()); 
		
		pictureView = new PictureView(picture.createObservable()); 
		pictureView.addMouseListener(this);
		add(pictureView, BorderLayout.CENTER); 
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		xCoordinate = e.getX();
		yCoordinate = e.getY();
		Pixel pixel = pictureView.getPicture().getPixel(xCoordinate, yCoordinate); 
		red = (double) Math.round(pixel.getRed()*100)/100;
		green = (double) Math.round(pixel.getGreen()*100)/100;
		blue = (double) Math.round(pixel.getBlue()*100)/100;
		brightness = (double) Math.round(pixel.getIntensity()*100)/100; 
		labelPanel.removeAll(); 
		pixelInfoLabel();
		labelPanel.revalidate(); 
	}
	
	public JPanel pixelInfoLabel() {
		labelPanel.setLayout(new GridLayout(6,1, 0, 0));
		String[] pixelInfo = {"X: " + xCoordinate, 
							  "Y: " + yCoordinate, 
				              "Red: " + red, 
				              "Green: " + green, 
				              "Blue: " + blue, 
				              "Brightness: " + brightness};
		for (int i = 0; i <pixelInfo.length; i++) {
			JLabel label = new JLabel(pixelInfo[i]); 
			labelPanel.add(label); 
		}
		return labelPanel;
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}
}
