package a7;

import java.awt.BorderLayout;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class FramePuzzle {

	public static void main(String[] args) throws IOException {
		Picture pic = A7Helper.readFromURL("http://www.cs.unc.edu/~kmp/kmp-in-namibia.jpg");
		FramePuzzleWidget framePuzzleWidget = new FramePuzzleWidget(pic);
		
		JFrame mainFrame = new JFrame(); 
		mainFrame.setTitle("Assignment 7 Frame Puzzle");
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel topPanel = new JPanel(); 
		topPanel.setLayout(new BorderLayout()); 
		topPanel.add(framePuzzleWidget, BorderLayout.CENTER); 
		mainFrame.setContentPane(topPanel);
		
		
		mainFrame.pack(); 
		mainFrame.setVisible(true);

	}

}
