package a7;

public interface RegisteredROIObserver extends ROIObserver {

	Region getRegion();
	ROIObserver getObserver();
}
