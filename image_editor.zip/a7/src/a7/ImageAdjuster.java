package a7;

import java.awt.BorderLayout;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class ImageAdjuster {

	public static void main(String[] args) throws IOException {
		Picture pic = A7Helper.readFromURL("http://www.cs.unc.edu/~kmp/kmp-in-namibia.jpg");
		ImageAdjusterWidget adjusterWidget = new ImageAdjusterWidget(pic);
		
		JFrame mainFrame = new JFrame(); 
		mainFrame.setTitle("Assignment 7 Image Adjuster");
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel topPanel = new JPanel(); 
		topPanel.setLayout(new BorderLayout()); 
		topPanel.add(adjusterWidget, BorderLayout.CENTER); 
		mainFrame.setContentPane(topPanel);
		
		topPanel.add(adjusterWidget.addSliders(), BorderLayout.SOUTH); 
		
		mainFrame.pack(); 
		mainFrame.setVisible(true);

	}

}
