package a7;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ImageAdjusterWidget extends JPanel implements ChangeListener {

	private PictureView pictureView;
	private Picture pic; 
	private JPanel sliderPanel = new JPanel();  
	private JSlider blurSlider, saturationSlider, brightnessSlider; 
	
	public ImageAdjusterWidget(Picture picture) {
		if (picture == null) {
			throw new IllegalArgumentException("picture is null"); 
		}

		setLayout(new BorderLayout());
		
		pictureView = new PictureView(picture.createObservable());
		pic = pictureView.getPicture(); 
		add(pictureView, BorderLayout.CENTER); 
		
		
	}
	
	public JPanel addSliders() {
		sliderPanel.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel blurSliderPanel = new JPanel(); 
		blurSliderPanel.setLayout(new BorderLayout());
		blurSlider = new JSlider(0, 5, 0);
		blurSlider.setPaintTicks(true); 
		blurSlider.setSnapToTicks(true);
		blurSlider.setPaintLabels(true);
		blurSlider.setMajorTickSpacing(1); 
		blurSlider.addChangeListener(this);
		blurSliderPanel.add(new JLabel("Blur: "), BorderLayout.WEST); 
		blurSliderPanel.add(blurSlider, BorderLayout.CENTER); 
		
		JPanel saturationSliderPanel = new JPanel();
		saturationSliderPanel.setLayout(new BorderLayout()); 
		saturationSlider = new JSlider(-100, 100, 0);
		saturationSlider.setPaintTicks(true); 
		saturationSlider.setSnapToTicks(true);
		saturationSlider.setPaintLabels(true);
		saturationSlider.setMajorTickSpacing(25); 
		saturationSlider.addChangeListener(this);
		saturationSliderPanel.add(new JLabel("Saturation: "), BorderLayout.WEST); 
		saturationSliderPanel.add(saturationSlider, BorderLayout.CENTER); 
		
		JPanel brightnessSliderPanel = new JPanel();
		brightnessSliderPanel.setLayout(new BorderLayout());
		brightnessSlider = new JSlider(-100, 100, 0);
		brightnessSlider.setPaintTicks(true); 
		brightnessSlider.setSnapToTicks(true);
		brightnessSlider.setPaintLabels(true);
		brightnessSlider.setMajorTickSpacing(25); 
		brightnessSlider.addChangeListener(this); 
		brightnessSliderPanel.add(new JLabel("Brightness: "), BorderLayout.WEST); 
		brightnessSliderPanel.add(brightnessSlider, BorderLayout.CENTER); 
		
		sliderPanel.add(blurSliderPanel);
		sliderPanel.add(saturationSliderPanel);
		sliderPanel.add(brightnessSliderPanel);
		
		return sliderPanel;
	}
	
	public Pixel blurPixel(Picture picture, int x, int y) {
		int blurSize = blurSlider.getValue(); 
		double totalRed = 0, totalGreen = 0, totalBlue = 0;
		int countPixel = 0;
		
		for (int i=x-blurSize; i<=x+blurSize; i++) {
			for (int j=y-blurSize; j<=y+blurSize; j++) {
				try {
					picture.getPixel(i, j);
					totalRed += picture.getPixel(i, j).getRed();
					totalGreen += picture.getPixel(i, j).getGreen(); 
					totalBlue += picture.getPixel(i, j).getBlue(); 
					countPixel++; 
				} catch (IllegalArgumentException e) {
					
				}
			}
		}
		double newRed = totalRed/countPixel;
		double newGreen = totalGreen/countPixel;
		double newBlue = totalBlue/countPixel; 
		return new ColorPixel(newRed, newGreen, newBlue); 
	}
	
	public Pixel brightenPixel(Pixel[][] parray, int x, int y) {
		double brightnessFactor = brightnessSlider.getValue(); 
		Pixel brightenedPixel; 
		
		if (brightnessFactor < 0) {
			brightenedPixel = parray[x][y].darken((Math.abs(brightnessFactor))/100); 
		} else if (brightnessFactor > 0) {
			brightenedPixel = parray[x][y].lighten(brightnessFactor/100);
		} else {
			brightenedPixel = parray[x][y];
		}
		 
		return brightenedPixel; 
	}
	
	public Pixel saturatePixel(Pixel[][] parray, int x, int y) {
		double saturationFactor = saturationSlider.getValue();
		double brightnessFactor = parray[x][y].getIntensity(); 
		double newRed, newGreen, newBlue; 
		double largestComponent;
		Pixel pixel = parray[x][y]; 
		Pixel saturatedPixel;
		
		if ((saturationFactor < 0) && (saturationFactor >= -100)) {
			newRed = pixel.getRed() * (1.0 + (saturationFactor/100.0)) - (brightnessFactor*saturationFactor/100.0);
			newGreen = pixel.getGreen() * (1.0 + (saturationFactor/100.0)) - (brightnessFactor*saturationFactor/100.0);
			newBlue = pixel.getBlue() * (1.0 + (saturationFactor/100.0)) - (brightnessFactor*saturationFactor/100.0);
			saturatedPixel = new ColorPixel(newRed, newGreen, newBlue); 
		} else if ((saturationFactor > 0) && (saturationFactor <= 100)) {
			
			try {	
				largestComponent = pixel.getRed() > pixel.getGreen() ? pixel.getRed() : pixel.getGreen();
				largestComponent = largestComponent > pixel.getBlue() ? largestComponent : pixel.getBlue(); 
				newRed = pixel.getRed() * ((largestComponent + ((1.0-largestComponent) * (saturationFactor/100.0))) / largestComponent); 
				newGreen = pixel.getGreen() * ((largestComponent + ((1.0-largestComponent) * (saturationFactor/100.0))) / largestComponent); 
				newBlue = pixel.getBlue() * ((largestComponent + ((1.0-largestComponent) * (saturationFactor/100.0))) / largestComponent); 
				saturatedPixel = new ColorPixel(newRed, newGreen, newBlue); 
			} catch (Exception e) {
				saturatedPixel = new ColorPixel(0,0,0); 
			}
		} else {
			saturatedPixel = parray[x][y]; 
		}
		return saturatedPixel;
	}

	public void stateChanged(ChangeEvent e) {
		if (!blurSlider.getValueIsAdjusting() && !brightnessSlider.getValueIsAdjusting() && !saturationSlider.getValueIsAdjusting()) {
			updatePicture(pic);
		}
		
	}
	
	private PictureView updatePicture(Picture picture) {
		Pixel[][] pixelArray = new Pixel[picture.getWidth()][picture.getHeight()]; 
		for (int i=0; i<picture.getWidth(); i++) {
			for (int j=0; j<picture.getHeight(); j++) {
				pixelArray[i][j] = blurPixel(picture, i, j); 
				pixelArray[i][j] = brightenPixel(pixelArray, i, j);
				pixelArray[i][j] = saturatePixel(pixelArray, i, j); 
			}
		}
	
		Picture copyPic = new MutablePixelArrayPicture(pixelArray, picture.getCaption());
		ObservablePicture observablePic = new ObservablePictureImpl(copyPic); 
		pictureView.setPicture(observablePic);
		return pictureView;
		 
	}

}
