package a7;

import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JPanel;

public class FramePuzzleWidget extends JPanel implements MouseListener, KeyListener {

	private PictureView pictureView, whitePiece;
	private Picture pic, movingWhitePiece, movingPuzzlePiece;
	private List<PictureView> extractPictureList, puzzlePiecesList;
	private int xCoordinatePuzzlePiece = 0, yCoordinatePuzzlePiece = 0;
	private int xCoordinate = 4, yCoordinate = 4;
	private PictureView[][] puzzlePieces = new PictureView[5][5];

	public FramePuzzleWidget(Picture picture) {
		if (picture == null) {
			throw new IllegalArgumentException("picture is null");
		}

		setLayout(new GridLayout(5, 5));

		pictureView = new PictureView(picture.createObservable());
		pic = pictureView.getPicture();

		createPuzzlePieces(pic);
		addPuzzlePieces();

		this.addKeyListener(this);
		this.addMouseListener(this);

		trackPuzzlePiece(pic);

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (yCoordinate == 4) {
				return;
			} else {
				movingWhitePiece = puzzlePieces[yCoordinate][xCoordinate].getPicture();
				movingPuzzlePiece = puzzlePieces[yCoordinate + 1][xCoordinate].getPicture();
				puzzlePieces[yCoordinate][xCoordinate].setPicture(movingPuzzlePiece.createObservable());
				puzzlePieces[yCoordinate + 1][xCoordinate].setPicture(movingWhitePiece.createObservable());
				yCoordinate++;
				revalidate();
			}
		} else if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (yCoordinate == 0) {
				return;
			} else {
				movingWhitePiece = puzzlePieces[yCoordinate][xCoordinate].getPicture();
				movingPuzzlePiece = puzzlePieces[yCoordinate - 1][xCoordinate].getPicture();
				puzzlePieces[yCoordinate][xCoordinate].setPicture(movingPuzzlePiece.createObservable());
				puzzlePieces[yCoordinate - 1][xCoordinate].setPicture(movingWhitePiece.createObservable());
				yCoordinate--;
				revalidate();
			}

		} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (xCoordinate == 4) {
				return;
			} else {
				movingWhitePiece = puzzlePieces[yCoordinate][xCoordinate].getPicture();
				movingPuzzlePiece = puzzlePieces[yCoordinate][xCoordinate + 1].getPicture();
				puzzlePieces[yCoordinate][xCoordinate].setPicture(movingPuzzlePiece.createObservable());
				puzzlePieces[yCoordinate][xCoordinate + 1].setPicture(movingWhitePiece.createObservable());
				xCoordinate++;
				revalidate();
			}

		} else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (xCoordinate == 0) {
				return;
			} else {
				movingWhitePiece = puzzlePieces[yCoordinate][xCoordinate].getPicture();
				movingPuzzlePiece = puzzlePieces[yCoordinate][xCoordinate - 1].getPicture();
				puzzlePieces[yCoordinate][xCoordinate].setPicture(movingPuzzlePiece.createObservable());
				puzzlePieces[yCoordinate][xCoordinate - 1].setPicture(movingWhitePiece.createObservable());
				xCoordinate--;
				revalidate();
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {

	}

	@Override
	public void keyTyped(KeyEvent arg0) {

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int xclick = 0;
		int yclick = 0;
		for (int i = xCoordinatePuzzlePiece; i < 5; i++) {
			for (int j = yCoordinatePuzzlePiece; j < 5; j++) {
				if (e.getSource() == puzzlePieces[j][i]) {
					xclick = i;
					yclick = j;
				}
			}
		}
		if (yclick == yCoordinate) {
			int xiterator = xCoordinate;
			if (xclick < xCoordinate) {
				for (int k = 0; k < Math.abs(xclick - xiterator); k++) {
					movingWhitePiece = puzzlePieces[yCoordinate][xCoordinate].getPicture();
					movingPuzzlePiece = puzzlePieces[yCoordinate][xCoordinate - 1].getPicture();
					puzzlePieces[yCoordinate][xCoordinate].setPicture(movingPuzzlePiece.createObservable());
					puzzlePieces[yCoordinate][xCoordinate - 1].setPicture(movingWhitePiece.createObservable());
					xCoordinate--;
					revalidate();
				}
			} else if (xclick > xCoordinate) {
				for (int k = 0; k < Math.abs(xclick - xiterator); k++) {
					movingWhitePiece = puzzlePieces[yCoordinate][xCoordinate].getPicture();
					movingPuzzlePiece = puzzlePieces[yCoordinate][xCoordinate + 1].getPicture();
					puzzlePieces[yCoordinate][xCoordinate].setPicture(movingPuzzlePiece.createObservable());
					puzzlePieces[yCoordinate][xCoordinate + 1].setPicture(movingWhitePiece.createObservable());
					xCoordinate++;
					revalidate();
				}
			}
		} else if (xclick == xCoordinate) {
			int yiterator = yCoordinate;
			if (yclick < yCoordinate) {
				for (int k = 0; k < Math.abs(yclick - yiterator); k++) {
					movingWhitePiece = puzzlePieces[yCoordinate][xCoordinate].getPicture();
					movingPuzzlePiece = puzzlePieces[yCoordinate - 1][xCoordinate].getPicture();
					puzzlePieces[yCoordinate][xCoordinate].setPicture(movingPuzzlePiece.createObservable());
					puzzlePieces[yCoordinate - 1][xCoordinate].setPicture(movingWhitePiece.createObservable());
					yCoordinate--;
					revalidate();
				}
			} else if (yclick > yCoordinate) {
				for (int k = 0; k < Math.abs(yclick - yiterator); k++) {
					movingWhitePiece = puzzlePieces[yCoordinate][xCoordinate].getPicture();
					movingPuzzlePiece = puzzlePieces[yCoordinate + 1][xCoordinate].getPicture();
					puzzlePieces[yCoordinate][xCoordinate].setPicture(movingPuzzlePiece.createObservable());
					puzzlePieces[yCoordinate + 1][xCoordinate].setPicture(movingWhitePiece.createObservable());
					yCoordinate++;
					revalidate();
				}
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {

	}

	@Override
	public void mouseExited(MouseEvent arg0) {

	}

	@Override
	public void mousePressed(MouseEvent arg0) {

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {

	}

	private List<PictureView> createPuzzlePieces(Picture picture) {
		int x = 0, y = 0;
		int width = pic.getWidth() / 5;
		int height = pic.getHeight() / 5;
		extractPictureList = new ArrayList<PictureView>();
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				if (i == 4 && j == 4) {
					Picture blankPiece = pic.extract(x, y, pic.getWidth() - (4 * width),
							pic.getHeight() - (4 * height));
					blankPiece.paint(0, 0, blankPiece.getWidth(), blankPiece.getHeight(), new ColorPixel(1, 1, 1), 1.0);
					whitePiece = convertToPictureView(blankPiece);
				} else if (i == 4) {
					Picture bottomPiece = pic.extract(x, y, width, pic.getHeight() - (4 * height));
					extractPictureList.add(convertToPictureView(bottomPiece));
					x += width;
				} else if (j == 4) {
					Picture rightEdgePiece = pic.extract(x, y, pic.getWidth() - (4 * (width)), height);
					extractPictureList.add(convertToPictureView(rightEdgePiece));
					y += height;
					x = 0;
				} else {
					Picture regularPiece = pic.extract(x, y, width, height);
					extractPictureList.add(convertToPictureView(regularPiece));
					x += width;
				}
			}
		}
		return extractPictureList;
	}

	private void addPuzzlePieces() {
		puzzlePiecesList = new ArrayList<PictureView>();
		Random random = new Random();
		int totalPics = 24;
		for (int i = 0; i < 24; i++) {
			int randomNum = random.nextInt(totalPics);
			PictureView pics = extractPictureList.get(randomNum);
			add(pics);
			puzzlePiecesList.add(extractPictureList.get(randomNum));
			extractPictureList.remove(randomNum);
			totalPics -= 1;
		}
		add(whitePiece);
	}

	private PictureView[][] trackPuzzlePiece(Picture picture) {
		int gridIndex = 0;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				if (i == 4 && j == 4) {
					puzzlePieces[i][j] = whitePiece;
					puzzlePieces[i][j].addKeyListener(this);
					puzzlePieces[i][j].addMouseListener(this);
				} else {
					puzzlePieces[i][j] = puzzlePiecesList.get(gridIndex);
					puzzlePieces[i][j].addKeyListener(this);
					puzzlePieces[i][j].addMouseListener(this);
					gridIndex++;
				}
			}
		}
		return puzzlePieces;
	}

	private PictureView convertToPictureView(Picture picture) {
		ObservablePicture observablePicture = new ObservablePictureImpl(picture);
		PictureView picView = new PictureView(observablePicture);
		return picView;
	}

}
